function DashView() {
    return ( <div>概况</div> );
}

export default DashView;