function EditProduce() {
    return ( <div>编辑产品</div> );
}

export default EditProduce;