function AddProdeue() {
    return ( <div>添加产品</div> );
}

export default AddProdeue;