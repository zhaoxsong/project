import RouterView from './router/index'
function App(){
  return (<RouterView />)
}
export default App